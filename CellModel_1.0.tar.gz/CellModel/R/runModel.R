runModel <- function(initialNum, runTime, density = 0.05,
                     meanGrowth = 0.15, varGrowth = 0.0, maxMigration = 0.5,
                     maxDeform = 0.075, maxRotate = 0.3, epsilon = 0.05,
                     delta = 5.0)
{
  
  output <- CellModel(initialNum, runTime, density, meanGrowth,
                    varGrowth, maxMigration, maxDeform, maxRotate,
                    epsilon, delta)
  
  cellMat <- new("cellMatrix", output)
  
  return(cellMat)
  
}
