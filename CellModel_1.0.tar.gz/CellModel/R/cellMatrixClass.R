setClass("cellMatrix", representation("matrix"))
